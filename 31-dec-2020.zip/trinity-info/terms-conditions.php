<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
<section class="pad-tb light-blue" style="margin-top : 5%">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="common-heading text-left">
                    <h2 class="mb0">Terms and Conditions</h2>
                </div>
            </div>
        </div>
        <div class="row mt80">
            <div class="col-md-12 mb30">
                <h4>QUOTATIONS AND ESTIMATES</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>All quotations and estimates gave by Trinity Info Pvt Ltd are legitimate for a time of 30 days from date of issue. Citations not acknowledged inside this time span must be re-given.</li>
                        <li>All quotations are needed to be acknowledged utilizing the provided Quotation Acceptance Form and got back to Trinity Info Pvt Ltd inside the 30 day time span from date of issuance.</li>
                        <li>All provided cost estimates, barring where demonstrated, do not include Goods and Services Tax.</li>
                        <li>Estimates might be given by Trinity Info Pvt Ltd to offer the customer a guide on the projected costing of an undertaking before any revelation or exploration for said project. All estimates will be obviously set apart all things considered and are not an indication of the exact final cost to develop the application.</li>
                        <li>All appraisals should be formalized to a quotation or receipt before acknowledgment by one or the other party as the last expense of the application.</li>
                        <li>Trinity Info Pvt Ltd maintains all authority to suspend the services/quotation whenever, with no earlier data.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>PAYMENT TERMS</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>All quotations provided by Trinity Info Pvt Ltd, require a 50% deposit upon acceptance.</li>
                        <li>Unless prior arrangement has been made, final payment is strictly net 10 days from the date of completion.</li>
                        <li>Any cost arising from payment clearings or transaction charges are solely the responsibility of the client and will be charged as such.</li>
                        <li>Trinity Info Pvt Ltd will commence work on the quoted application once any deposited funds have cleared.</li>
                        <li>The customer will not be entitled for any service in case of delay in payment for more than 10 days from the final date of installation / date of project / module completion.</li>
                        <li>If opted for service beyond the 12 months of maintenance period or as agreed by Trinity Info Pvt Ltd, The Annual Maintenance Charges (AMC) will be normally applicable 50% (PERCENT) of original development cost of Project / Module; each year the development cost for new modules will be added to the initial development cost for the calculation of the AMC.</li>
                        <li>The AMC percentage shall be decided by the Trinity Info Pvt Ltd; which depends upon the amount of efforts and work required. This % may vary each year.</li>
                        <li>Trinity Info Pvt Ltd disclaims all warranties or conditions, whether expressed or implied, (including without limitation implied, warranties or conditions of information and context). We consider ourselves and intend to be subject to the jurisdiction of India.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>CANCELLATIONS</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>Should the client wish to cancel acceptance of the quotation, Trinity Info Pvt Ltd will invoice the client for any work completed to date, as a percentage of the total work involved.</li>
                        <li>The minimum cancellation fee will be 30% of the signed quotation.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>CONTENT</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>Clients are required to ensure that the content of the Web | App.</li>
                        <li>The client shall further indemnify Trinity Info Pvt Ltd in respect of any claims, costs and expenses that may arise from any material included within the quoted application by Trinity Info Pvt Ltd at the client’s request.</li>
                        <li>Trinity Info Pvt Ltd reserves the right not to include any material supplied by the client within the quoted application if Trinity Info Pvt Ltd deems said material inappropriate of offensive.</li>
                        <li>Trinity Info Pvt Ltd will not populate the application with the final content unless said content is delivered to Trinity Info Pvt Ltd in digital format prior to commencement of work. Said content, if available, will be used for testing purposes and may not be formatted how the client requires it. If content is not available mock placeholder content will be used.</li>
                        <li>It is the client's responsibility, in all cases, to ensure the applications content is displayed and formatted as they require. If the client cannot format the applications content, Trinity Info Pvt Ltd will offer this service at Trinity Info Pvt Ltd' current hourly rate at the time of the request.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>PERMISSIONS AND COPYRIGHTS</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>The client will obtain all necessary permissions and authorities with respect to the use of all copy, graphics, logos, names and trademarks and any other material supplied by the client to Trinity Info Pvt Ltd.</li>
                        <li>Supply of said material by the client to Trinity Info Pvt Ltd shall be regarded as a guarantee from the client that all such permissions and authorities have been sought and obtained for said material.</li>
                        <li>No responsibility will be accepted by Trinity Info Pvt Ltd for damages or losses incurred by the client from the use of material for which permission or authority has not been obtained.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>ERRORS AND LIABILITIES</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>Trinity Info Pvt Ltd will pursue due care to ensure applications create by Trinity Info Pvt Ltd are free of errors.</li>
                        <li>Trinity Info Pvt Ltd will correct any errors made by Trinity Info Pvt Ltd staff in the undertaking of the quoted application.</li>
                        <li>Trinity Info Pvt Ltd does not accept responsibility for losses or damage arising from errors within any application.</li>
                        <li>Trinity Info Pvt Ltd does not accept responsibility for errors, damages, losses or additional costs that relate to third party products that Trinity Info Pvt Ltd may require completing the quoted application.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>ALTERATIONS</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>Any alterations requested by the client after development has begun will incur extra development and regression testing time. Dependent upon the alteration or change requested an average of 3 days extra development time per alteration should be allowed for. The 3 day average may not be indicative of the time required and can be extended commensurate of the time involved to implement said changes.</li>
                        <li>Trinity Info Pvt Ltd will not accept responsibility for any alterations performed by the client or any third party which may cause or induce errors within the quoted application.</li>
                        <li>If Trinity Info Pvt Ltd are required to correct said alterations or errors resulting from said alterations, induced, injected or otherwise caused by parties other than Trinity Info Pvt Ltd, the client will be charged at the hourly rate that is current for Trinity Info Pvt Ltd at the time said errors are to be fixed.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>COMPLETION OF WORK</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>All time frames offered by Trinity Info Pvt Ltd to the client are estimates. The intrinsic nature of website development and its intricacies do not offer Trinity Info Pvt Ltd the luxury of defining definite time frames.</li>
                        <li>Trinity Info Pvt Ltd will endeavor to complete all work within the estimated timeframes discussed with the client in the quotation. However, Trinity Info Pvt Ltd will not be liable for any penalties, monies or hardships otherwise incurred by the client if the application cannot be delivered within the estimated time frame.</li>
                        <li>Trinity Info Pvt Ltd will not release the quoted application unless all payments have been met under the obligations of the quotation or work agreement.</li>
                        <li>The quoted application remains the property of Trinity Info Pvt Ltd web | app until all obligations have been met for release of said application to the client.</li>
                        <li>If Trinity Info Pvt Ltd is working as a third party to another company, said company is responsible in meeting the obligations for release of the quote application to their client.</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 mb30">
                <h4>CHANGES TO SITE AND THESE TERMS AND CONDITIONS</h4> <br>
                <div class="trinity-list">
                    <ul class="key-points">
                        <li>This Site and these Trinity Info Pvt Ltd Terms and Conditions may be amended, revised, changed, updated or modified by Trinity Info Pvt Ltd with or without notice. Please review this link on a regular basis for changes. Continued use of this Site following any change to the Trinity Info Pvt Ltd Terms and Conditions constitutes your acceptance of any such change to the Trinity Info Pvt Ltd Terms and Conditions.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>

</html>