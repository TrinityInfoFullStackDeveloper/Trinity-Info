<footer>
    <div class="footer-svg">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
            viewBox="0 0 1920 80" style="enable-background:new 0 0 1920 80;" xml:space="preserve">
            <path class="st0" d="M0,27.2c589.2,129.4,1044-69,1920,31v-60H3.2L0,27.2z"></path>
        </svg>
    </div>
    <div class="footer-row2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 col-sm-12 text-center">
                    <a class="navbar-brand img-ctr" href="#"> <img src="images/logo.png" alt="Logo" width="20%"></a>
                    <ul class="footer-link-v2 link-hover mt30">
                        <li><a href="about-us">About Us</a></li>
                        <li><a href="why-us">Why Us</a></li>
                        <li><a href="coming-soon#">Mission and Vision</a></li>
                        <li><a href="development-process">Development Process</a></li>
                        <li><a href="contact">Contact</a></li>
                    </ul>
                    <ul class="footer-link-v2 link-hover mt30">
                        <li><a href="privacy-policy">Privacy Policy</a></li>
                        <li><a href="terms-conditions">Terms and Condition</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <hr class="hline">
    <div class="footer-row3">
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-social-media-icons">
                            <a href="https://www.facebook.com/Trinity-Info-102776298331662" target="blank"><i
                                    class="fab fa-facebook"></i></a>
                            <a href="https://twitter.com/TrinityInfo1" target="blank"><i class="fab fa-twitter"></i></a>
                            <a href="https://www.instagram.com/trinityinfopvt/" target="blank"><i
                                    class="fab fa-instagram"></i></a>
                            <a href="https://www.linkedin.com/company/trinity-info" target="blank"><i
                                    class="fab fa-linkedin"></i></a>
                            <a href="https://www.youtube.com/channel/UCMdpbWYfQFcCHpvjBpNYd2A" target="blank"><i
                                    class="fab fa-youtube"></i></a>
                        </div>
                        <div class="footer-">
                            <p>Copyright © 2020 Trinity Info. All rights reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Button to Scrool Top -->
<a id="scrollUp" href="#top"></a>