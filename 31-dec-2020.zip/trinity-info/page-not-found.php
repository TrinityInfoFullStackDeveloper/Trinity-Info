<?php
    include './phplib/header.php';
    // include './phplib/navbar.php';
?>
    
</body>
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>
</html>