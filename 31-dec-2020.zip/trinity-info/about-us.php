<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
<section class="hero-section hero-digital-agency-1 dg-bg--1" id="home">
				<div class="text-block">
					<div class="container">
						<div class="row">
							<div class="col-lg-6 v-center">
								<div class="header-heading">
									<h1 class="wow fadeInUp text-effect-1" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">About Us</h1>
									<p class="wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">We began our excursion with an enthusiasm for making web solutions and mobile application supporting entrepreneurs and startups. It began with four peoples however now we have 25+ members.</p>
                  <p>We have faith in 100% client relationship management that is the reason all our contact with a client and requirement gathering are done clearly by our capable group of specialists with solid involvement with advancement.</p>
									<div class="-content-sec  d-flex mt60 v-center">
										<div class="mr25"><a href="#mision" class="btn-main bg-btn4 lnk">GET STARTED<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a></div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 v-center tilt-3d">
								<div class="img-with-shape base" data-tilt="" data-tilt-max="8" data-tilt-speed="2000" style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1); transition: all 2000ms cubic-bezier(0.03, 0.98, 0.52, 0.99) 0s;">
									<!-- <div class="shape-dg-1 dg-hero-shp2"><img src="images/shape/shape-dg-1.png" alt="shape" class="img-fluid niwax" data-rellax-speed="-3" style="transform: translate3d(0px, 0px, 0px);"></div> -->
									<img src="images/about/digi-agency-dg.jpg" alt="digital agency" class="img-fluid dg-hero-img0">
									<!-- <div class="shape-dg-1 dg-hero-shp1a"><img src="images/shape/dots-dg.png" alt="shape" class="img-fluid niwax" data-rellax-speed="-6" style="transform: translate3d(0px, 0px, 0px);"></div> -->
									<!-- <div class="shape-dg-1 dg-hero-shp3"><img src="images/shape/shape-dg-2.png" alt="shape" class="img-fluid niwax" data-rellax-speed="4" style="transform: translate3d(0px, 0px, 0px);"></div> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
  <section class="service-block pad-tb light-dark" id="mision">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="common-heading ptag">
            <span>About</span>
            <h2>Our Mission</h2>
            <p>Our solid determination is to lift startups by bringing their imaginative business thought quicker into the market.</p>
          </div>
        </div>
      </div>
      <div class="row upset justify-content-center mt60">
        <div class="col-lg-4 v-center order1">
          <div class="image-block1">
            <img src="images/process/process-1.jpg" alt="Process" class="img-fluid">
          </div>
        </div>
        <div class="col-lg-7 v-center order2">
          <div class="ps-block">
            <h3>First Class Business Solutions For You</h3>
            <p>We are tapping into the power of digital world, creating high impact solutions to boost the business efficiency. Trinity Info as a Software Outsourcing Company is committed to provide End-to End Customized Solutions to our global customers and tackle the technology problems faced by businesses.</p>
          </div>
        </div>
      </div>
      <div class="row upset justify-content-center mt60">
        <div class="col-lg-7 v-center order2">
          <div class="ps-block">
            <h3>Start Your Business Today With Trinity Info</h3>
            <p>We realize that any service we provide should create happy customers, employees, and help in operational efficiencies and give you the bandwidth to focus on your market growth and customer footprint. Our teams have this focus ingrained in all the work they do.</p>
            <p>You focus on innovating and developing your products & services and leave the talent hunt to us - thats one thing less that you have to manage.</p>
          </div>
        </div>
        <div class="col-lg-4 v-center order1">
          <div class="image-block1">
            <img src="images/process/process-2.jpg" alt="Process" class="img-fluid">
          </div>
        </div>
      </div>
      <div class="row upset justify-content-center mt60">
        <div class="col-lg-4 v-center order1">
          <div class="image-block1">
            <img src="images/process/process-3.jpg" alt="Process" class="img-fluid">
          </div>
        </div>
        <div class="col-lg-7 v-center order2">
          <div class="ps-block">
            <h3>We Are Qualified & Professional</h3>
            <p>In Trinity Info, we enable clients with the best in market IT & Engineering Talent. Our clients enjoy a quick, hassle free experience, save significant costs & leverage the expertise they need to drive business growth.</p>
          </div>
        </div>
      </div>
      </div>
    </div>
  </section>
</body>
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>
</html>