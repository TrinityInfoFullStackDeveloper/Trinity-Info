<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
    <section class="about-sec-rpb pad-tb">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-lg-10">
                <div class="common-heading">
                    <span>Fly High With Our Mobile Technologies</span>
                    <h1> </h1>
                    <p><span class="text-radius text-light text-animation bg-b">Trinity Info's</span>
                    mobile app developers leverage cutting-edge mobile technology to build user-centric mobile apps.</p>
                    <h3 class="mt30 mb30">Big Ideas, creative people, new technology.</h3>
                    <p>Our highly efficient, interactive and easy- to-use apps will help you 
                    optimize your business operations.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End About-->
<!--Start Service-->
<section class="service-section-prb pad-tb">
    <div class="container">
        <div class="row upset">
            <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="col-lg-6-cus wow fadeInUp"
                data-wow-delay=".2s">
                <div class="service-sec-brp srvc-bg-nx bg-gradient13 text-w">
                    <h4 class="mb10">INTEGRATED SERVICES</h4>
                    <p>Our talented team of mobile app developers will address all your concerns and help 
                    you fulfill your business objectives.</p>
                    <a href="coming-soon" class="mt20 link-prb">Learn More <i
                            class="fas fa-chevron-right"></i></a>
                </div>
            </div>
            <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="col-lg-3-cus wow fadeInUp"
                data-wow-delay=".4s">
                <div class="service-sec-list srvc-bg-nx srcl1">
                    <img src="images/icons/app.svg" alt="service">
                    <h5 class="mb10">IOS Development</h5>
                    <ul class="-service-list">
                        <li> <a >Flutter</a> </li>
                        <li> <a >React Native</a> </li>
                        <li> <a >Swift</a> </li>
                    </ul>
                    <p>We develop highly reliable and receptive iPhone mobile apps 
                    with a seamless user experience!</p>
                </div>
            </div>
            <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="col-lg-3-cus wow fadeInUp"
                data-wow-delay=".6s">
                <div class="service-sec-list  srvc-bg-nx srcl2">
                    <img src="images/icons/app.svg" alt="service">
                    <h5 class="mb10">Android Development</h5>
                    <ul class="-service-list">
                        <li> <a >Flutter</a> </li>
                        <li> <a >React Native</a> </li>
                        <li> <a >Kotlin </a> </li>
                    </ul>
                    <p>Take your business to the next level with our Android 
                    app development services.</p>
                </div>
            </div>
            <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="col-lg-3-cus mt30- wow fadeInUp"
                data-wow-delay=".8s">
                <div class="service-sec-list mob-icon srvc-bg-nx srcl3">
                    <img src="images/icons/Complete-Transparency.svg" alt="service">
                    <h5 class="mb10">Complete Transparency</h5>
                    <p>We’ll keep you updated on our progress at every stage of your mobile app development.</p>
                </div>
            </div>
            <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="col-lg-3-cus mt30- wow fadeInUp"
                data-wow-delay=".8s">
                <div class="service-sec-list srvc-bg-nx srcl3">
                    <img src="images/icons/Excellent-Mobile-App-Design.svg" alt="service">
                    <h5 class="mb10">Excellent Mobile App Design</h5>
                    <p>All our mobile app development and designs are unique and offer your customers seamless navigation.</p>
                </div>
            </div>
            <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="col-lg-3-cus mt30- wow fadeInUp"
                data-wow-delay=".8s">
                <div class="service-sec-list srvc-bg-nx srcl3">
                    <img src="images/icons/Forward-Looking.svg" alt="service">
                    <h5 class="mb10">Forward Looking</h5>
                    <p>We always looks at the bigger picture and executes design steps 
                    on the basis of strategy and data insights</p>
                </div>
            </div>
        </div>
        <div class="-cta-btn mt70">
            <div class="free-cta-title v-center zoomInDown wow" data-wow-delay="1.4s">
                <p>Hire a <span>Dedicated Developer</span></p>
                <a href="hire-developer" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span
                        class="circle"></span></a>
            </div>
        </div>
    </div>
</section>
</body>
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>
</html>