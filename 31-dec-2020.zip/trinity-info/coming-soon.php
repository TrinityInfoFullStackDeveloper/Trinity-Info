<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta charset="utf-8" />
    <title>Trinity Info | Coming Soon..</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--website-favicon-->
    <link href="images/favicon.png" rel="icon">
    <!--plugin-css-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/plugin.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Poppins:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <!-- template-style-->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
</head>

<body>
    <!--Start Header -->
    <header class="nav-bg-w main-header navfix fixed-top menu-white header-pr">
        <div class="container-fluid m-pad">
            <div class="menu-header">
                <div class="dsk-logo">
                    <a class="nav-brand" href="index">
                        <img src="images/white-logo.png" alt="Logo" class="mega-white-logo" />
                        <img src="images/logo.png" alt="Logo" class="mega-darks-logo" />
                    </a>
                </div>
            </div>
        </div>
    </header>
    <section class="error bg-gradient pad-tb">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb50">
                    <div class="layer-div">
                        <div class="error-block">
                            <h1>Coming Soon</h1>
                            <p>UNDER DEVELOPMENT PROCESS</p>
                            <div class="images mt20">
                                <img src="./images/coming-soon.png" width="440" alt="error page" class="img-fluid" />
                            </div>
                            <a href="./" class="btn-outline">Back to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End 404 Error-->
    <!--scroll to top-->
    <a id="scrollUp" href="#top"></a>
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/plugin.min.js"></script>
    <!--common script file-->
    <script src="js/main.js"></script>
</body>

</html>