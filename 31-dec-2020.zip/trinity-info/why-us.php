<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
<section class="why-choos-lg pad-tb deep-dark mt20">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="common-heading text-l">
                    <span>Why Choose Us</span>
                    <h2 class="mb20">Why The Trinity <span class="text-second text-bold">Ranked Top</span> Among The
                        Leading Web & App Development Companies</h2>
                    <p>We deliver solutions that meet client's needs, expectations and budget.</p>
                    <div class="itm-media-object mt40 tilt-3d">
                        <div class="media">
                            <div class="img-ab- base" data-tilt data-tilt-max="20" data-tilt-speed="1000"><img
                                    src="images/icons/dedicated-teams.png" alt="icon" class="layer"></div>
                            <div class="media-body">
                                <h4>Dedicated teams</h4>
                            </div>
                        </div>
                        <div class="media mt40">
                            <div class="img-ab- base" data-tilt data-tilt-max="20" data-tilt-speed="1000"><img
                                    src="images/icons/true-partners.png" alt="icon" class="layer"></div>
                            <div class="media-body">
                                <h4>True partners</h4>
                            </div>
                        </div>
                        <div class="media mt40">
                            <div class="img-ab- base" data-tilt data-tilt-max="20" data-tilt-speed="1000"> <img
                                    src="images/icons/global-know-how.png" alt="icon" class="layer"></div>
                            <div class="media-body">
                                <h4>Global know-how</h4>
                            </div>
                        </div>
                        <div class="media mt40">
                            <div class="img-ab- base" data-tilt data-tilt-max="20" data-tilt-speed="1000"> <img
                                    src="images/icons/focus-on-innovation.png" alt="icon" class="layer"></div>
                            <div class="media-body">
                                <h4>Focus on innovation</h4>
                            </div>
                        </div>
                        <div class="media mt40">
                            <div class="img-ab- base" data-tilt data-tilt-max="20" data-tilt-speed="1000"> <img
                                    src="images/icons/respect-clients.png" alt="icon" class="layer"></div>
                            <div class="media-body">
                                <h4>Respect of the client needs, culture, identity and objectives</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div data-tilt data-tilt-max="5" data-tilt-speed="1000" class="single-image wow text-center fadeIn"
                    data-wow-duration="2s"><img src="images/about/why-choose-us.jpg" alt="image" class="img-fluid">
                </div>
                <p class="text-center mt30">Our approach is distinctly innovative. We constantly seek new ways to
                    increase client
                    visibility and brand value. We also look to get the most out of advances in digitalization and
                    embrace client technology platforms. </p>
                <div class="cta-card mt60 text-center">
                    <h3 class="mb20">Let's Start a <span class="text-second text-bold">New Project</span> Together</h3>
                    <p>If you are a business owner that is ready to take the next step with
                        technology then contact us today!</p>
                    <a href="get-quote" class="btn-outline lnk mt30">Request A Quote <i
                            class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="dg-service2 dg-bg--2 pb130 pt130" id="services">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-8">
							<div class="common-heading-2 text-center">
								<span class="text-effect-1">Populor Services</span>
								<h2 class="mb30">We help Brands with</h2>
							</div>
						</div>
					</div>
					<div class="row upset ovr-bg1 ho-gdnt">
						<div class="col-lg-6 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
							<div class="s-block up-hor ovr-base">
								<div class="nn-card-set">
									<div class="s-card-icon"><img src="images/service/assured-services.png" alt="service" class="img-fluid"></div>
									<h4>Assured Services</h4>
									<p>We are always at the top in terms of client satisfaction.</p>									
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
							<div class="s-block up-hor ovr-base">
								<div class="nn-card-set">
									<div class="s-card-icon"><img src="images/service/worldwide-clients.png" alt="service" class="img-fluid"></div>
									<h4>Worldwide Clients</h4>
									<p>We are trusted by 20+ clients from worldwide.</p>									
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
							<div class="s-block up-hor ovr-base">
								<div class="nn-card-set">
									<div class="s-card-icon"><img src="images/service/next-gen-technology-provider.png" alt="service" class="img-fluid"></div>
									<h4>Next-Gen Technology Provider</h4>
									<p>Lifetime provider of uttermost tactics for your digital journey.</p>									
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
							<div class="s-block up-hor ovr-base">
								<div class="nn-card-set">
									<div class="s-card-icon"><img src="images/service/all-about-technology.png" alt="service" class="img-fluid"></div>
									<h4>It’s All About Technology</h4>
                                    <p>24*7 support from our expertise to your business.</p>		
								</div>
							</div>
						</div>
				</div>
                <div class="-cta-btn mt70">
            <div class="free-cta-title v-center zoomInDown wow" data-wow-delay="1.4s" style="visibility: visible; animation-delay: 1.4s; animation-name: zoomInDown;">
                <p>Hire a <span>Dedicated Developer</span></p>
                <a href="hire-developer" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
            </div>
        </div>
			</section>
</body>
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>
</html>