<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
<style>
header.nav-bg-w.main-header.navfix.fixed-top {
    background-color: #fff;
}
</style>
<section class="contact-page pad-tb section-nx">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 v-center">
                <div class="common-heading text-l">
                    <h2 class="mt0 mb0">Hire a Developer </h2><br>
                    <span>Please take a moment to fill the form.</span>
                    <p class="mb60 mt20">We will catch you as early as we receive the message</p>
                </div>
                <div class="form-block">
                    <form id="contact-form" method="post" action="php/contact.php" data-toggle="validator"
                        novalidate="true">
                        <div class="messages"></div>
                        <div class="fieldsets row">
                            <div class="col-md-6 form-group"><input class="valid" id="form_name" type="text" name="name"
                                    placeholder="Enter your name *" required="required" data-error="Name is required.">
                                <div class="msg0 hide help-block with-errors">Enter Name</div>
                            </div>
                            <div class="col-md-6 form-group"><input class="valid" id="form_email" type="email" name="email"
                                    placeholder="Enter your email *" required="required"
                                    data-error="Valid email is required.">
                                <div class="msg1 hide help-block with-errors">Enter Valid Mail Id</div>
                            </div>
                        </div>
                        <div class="fieldsets row">
                            <div class="col-md-6 form-group"><input class="valid" id="form_phone" type="text" name="phone"
                                    placeholder="Enter your Phone No *" required="required"
                                    data-error="Phone No is required.">
                                <div class="msg2 hide help-block with-errors">Enter Mobile Number</div>
                            </div>
                            <div class="col-md-6 form-group">
                            <input id="form_phone" class="valid" type="text" name="need"
                                    placeholder="Require a Developer" required="required" value="Hire a Developer!"
                                    data-error="Phone No is required.">
                                <div class="msg3 hide help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="fieldsets form-group"> <textarea class="valid" id="form_message" name="message"
                                placeholder="Message for me *" rows="4" required="required"
                                data-error="Please, leave us a message."></textarea>
                            <div class="msg4 hide help-block with-errors">Enter Message</div>
                        </div>

                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck" name="example1"
                                checked="checked">
                            <label class="custom-control-label" for="customCheck">I agree to the 
                            <a href="terms-conditions">Terms &amp; Conditions</a> of Trinity Info.</label>
                        </div>
                        <div class="fieldsets mt20">
                            <button type="submit" class="lnk btn-main bg-btn disabled">Submit <span
                                    class="circle dkpr"></span></button>
                        </div>
                        <p class="trm"><i class="fas fa-lock"></i>We hate spam, and we respect your privacy.</p>
                    </form>
                </div>
            </div>
            <div class="col-lg-5 v-center">
                <div class="contact-details">
                    <div class="contact-card wow fadeIn" data-wow-delay=".2s"
                        style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
                        <div class="info-card v-center">
                            <span><i class="fas fa-phone-alt"></i> Phone:</span>
                            <div class="info-body">
                                <p>Assistance hours: Monday – Friday, 9 am to 5 pm</p>
                                <a href="tel:+918072034933">(+91) 807 203 4933</a>
                            </div>
                        </div>
                    </div>
                    <div class="email-card mt30 wow fadeIn" data-wow-delay=".5s"
                        style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;">
                        <div class="info-card v-center">
                            <span><i class="fas fa-envelope"></i> Email:</span>
                            <div class="info-body">
                                <p>Our support team will get back to in 24-h during standard business hours.</p>
                                <a href="mailto:info@trinity-info-pvt-ltd.com">info@trinity-info-pvt-ltd.com</a>
                            </div>
                        </div>
                    </div>
                    <div class="skype-card mt30 wow fadeIn" data-wow-delay=".9s"
                        style="visibility: visible; animation-delay: 0.9s; animation-name: fadeIn;">
                        <div class="info-card v-center">
                            <span><i class="fab fa-skype"></i> Skype:</span>
                            <div class="info-body">
                                <p>We Are Online: Monday – Friday, 9 am to 5 pm</p>
                                <a href="skype:trinity-info.company?call">trinity-info.company</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Modal -->
<div class="popup-modalfull">
    <div class="modal loader" id="modalform-full">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center mt30">
                            <div class="col-md-9">
                                <div class="form-block fdgn2 mt10 mb10">
                                    <img src="./images/loader.gif" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup-modalfull">
    <div class="modal success" id="modalform-full">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center mt30">
                            <div class="col-md-9">
                                <div class="form-block fdgn2 mt10 mb10">
                                    <img src="./images/success.gif" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup-modalfull">
    <div class="modal failed" id="modalform-full">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center mt30">
                            <div class="col-md-9">
                                <div class="form-block fdgn2 mt10 mb10">
                                    <img src="./images/failed.gif" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal End -->
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>
<script>
$('#contact-form').submit(function(e) {
    e.preventDefault();
    var input = document.getElementsByClassName('valid');
    let count = 0;
    for (i = 0; i < input.length; i++) {
        if (input[i].value == "") {
            $('.msg' + i).removeClass('hide');
        } else {
            $('.msg' + i).addClass('hide');
            count++;
        }
    }
    if (count == input.length) {
        $.ajax({
            type: 'post',
            url: 'sendMail.php',
            data: $('form').serialize(),
            beforeSend: function() {
                $('.loader').show();
            },
            success: function(data) {
                $('.loader').hide();
                if (data) {
                    $('.success').show();
                    setTimeout(() => {
                        $('.success').hide();
                    }, 2000);
                } else {
                    $('.failed').show();
                    setTimeout(() => {
                        $('.failed').hide();
                    }, 2000);
                }
            }
        });
    }
});
</script>
</body>

</html>