<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
    <!--Start Hero-->
    <section class="hero-section hero-bg-bg1 bg-gradient1">
        <div class="text-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 v-center">
                        <div class="header-heading">
                            <h1 class="wow fadeInUp" data-wow-delay=".2s"><span class="xhighlight">Dream IT</span> Wish IT <br> <span>DO IT</span> </h1>
                            <p class="wow fadeInUp" data-wow-delay=".4s">INNOVATION SUPPORTING BOLD IDEAS THAT DRIVE REAL VALUE FROM IT</p>
                            <a href="coming-soon" class="btn-main bg-btn lnk wow fadeInUp" data-wow-delay=".6s">Get Started<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
                        </div>
                    </div>
                    <div class="col-lg-6 v-center">
                        <div class="single-image wow fadeIn" data-wow-delay=".5s">
                            <img src="images/hero/digital-marketing.png" alt="hero image" class="img-fluid" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Hero-->
    <!--Start About-->
    <section class="about-agency pad-tb">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 v-center">
                    <div class="image-block">
                        <img src="images/about/about-service.jpg" alt="about" class="img-fluid no-shadow" />
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="common-heading text-l">
                        <span>Your Most Trusted Business Partner</span>
                        <h2>10+ Years of Industry Experience</h2>
                        <p>We stay on top of our industry by being experts in yours.</p> <br>
                        <b>We Serve All Industries</b> <br>
                        <div class="niwax-list">
                            <ul class="list-style-">
                                <li>STARTUPS</li>
                                <li>HEALTH</li>
                                <li>REALESTATE</li>
                                <li>E-COMMERCE</li>
                                <li>ENTERPRISE</li>
                                <li>EDUCATION</li>
                            </ul>
                        </div>
                        <a href="coming-soon" class="btn-main bg-btn lnk mt30">Learn More <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About-->
    <!--Start Service-->
    <section class="service-section service-2 pad-tb">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="common-heading">
                        <h2 class="mb30">Our Featured Services</h2>
                    </div>
                </div>
            </div>
            <div class="row upset link-hover">
                <div class="col-lg-4 col-sm-4 mt30 wow fadeInUp" data-wow-delay=".2s">
                    <div class="wide-block service-img1" data-tilt data-tilt-max="2" data-tilt-speed="600">
                        <div class="block-space-">
                            <span>Development</span>
                            <h4>Web | Mobile Development</h4>
                            <a href="coming-soon">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 mt30  wow fadeInUp" data-wow-delay=".4s">
                    <div class="wide-block service-img2" data-tilt data-tilt-max="2" data-tilt-speed="600">
                        <div class="block-space-">
                            <span>Shoppify</span>
                            <h4>E-Commerce Applications</h4>
                            <a href="coming-soon">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 mt30  wow fadeInUp" data-wow-delay=".6s">
                    <div class="wide-block service-img3" data-tilt data-tilt-max="2" data-tilt-speed="600">
                        <div class="block-space-">
                            <span>Sleeky Design</span>
                            <h4>UI/UX Design</h4> <br> <br>
                            <a href="coming-soon">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 mt30 wow fadeInUp" data-wow-delay=".2s">
                    <div class="wide-block service-img1" data-tilt data-tilt-max="2" data-tilt-speed="600">
                        <div class="block-space-">
                            <span>Marketing</span>
                            <h4>Digital Media & PPC Advertising</h4>
                            <a href="coming-soon">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 mt30  wow fadeInUp" data-wow-delay=".4s">
                    <div class="wide-block service-img2" data-tilt data-tilt-max="2" data-tilt-speed="600">
                        <div class="block-space-">
                            <span>Assurity</span>
                            <h4>Quality Assurances</h4> <br><br>
                            <a href="coming-soon">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-4 mt30  wow fadeInUp" data-wow-delay=".6s">
                    <div class="wide-block service-img3" data-tilt data-tilt-max="2" data-tilt-speed="600">
                        <div class="block-space-">
                            <span>Guarding</span>
                            <h4>Data and Website Maintanes</h4>
                            <a href="coming-soon">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Service-->
    <!--Start statistics-->
    <div class="statistics-section bg-gradient pad-tb tilt3d">
        <div class="container">
            <div class="row justify-content-center t-ctr">
                <div class="col-lg-4 col-sm-6">
                    <div class="statistics">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="statistics-img">
                            <img src="images/icons/startup.svg" alt="years" class="img-fluid" />
                        </div>
                        <div class="statnumb">
                            <span class="counter">10</span><span>+</span>
                            <p>Year In Business</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="statistics">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="statistics-img">
                            <img src="images/icons/team.svg" alt="team" class="img-fluid" />
                        </div>
                        <div class="statnumb">
                            <span class="counter">50</span><span>+</span>
                            <p>Team Members</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row small t-ctr">
                <div class="col-lg-3 col-sm-6">
                    <div class="statistics">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="statistics-img">
                            <img src="images/icons/deal.svg" alt="happy" class="img-fluid" />
                        </div>
                        <div class="statnumb">
                            <span class="counter">100</span>
                            <p>Happy Clients</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="statistics">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="statistics-img">
                            <img src="images/icons/computers.svg" alt="project" class="img-fluid" />
                        </div>
                        <div class="statnumb counter-number">
                            <span class="counter">10</span><span>k</span>
                            <p>Projects Done</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="statistics">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="statistics-img">
                            <img src="images/icons/worker.svg" alt="work" class="img-fluid" />
                        </div>
                        <div class="statnumb">
                            <span class="counter">95</span><span>k</span>
                            <p>Hours Worked</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="statistics mb0">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="statistics-img">
                            <img src="images/icons/customer-service.svg" alt="support" class="img-fluid" />
                        </div>
                        <div class="statnumb">
                            <span>24/7</span>
                            <p>Support Available</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End statistics-->
    <!--Start work-category-->
    <section class="work-category pad-tb tilt3d">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 v-center">
                    <div class="common-heading text-l">
                        <span>Industries we work for</span>
                        <h2>Helping Businesses in All Domains</h2>
                        <p>Helping You Think More Innovatively ​About ​Your Business.</p>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="row upset">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="col-lg-4 col-sm-6 mt30">
                            <div class="s-block up-hor">
                                <div class="s-card-icon">
                                    <img src="images/icons/tech-support.svg" alt="service" class="img-fluid">
                                </div>
                                <p>TECH SUPPORT</p>
                            </div>
                        </div>
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="col-lg-4 col-sm-6 mt30">
                            <div class="s-block up-hor">
                                <div class="s-card-icon">
                                    <img src="./images/icons/it-service.svg" alt="service" class="img-fluid">
                                </div>
                                <p>MANAGED IT SERVICES </p>
                            </div>
                        </div>
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="col-lg-4 col-sm-6 mt30">
                            <div class="s-block up-hor">
                                <div class="s-card-icon">
                                    <img src="images/icons/firewall.svg" alt="service" class="img-fluid">
                                </div>
                                <p>SECURITY</p>
                            </div>
                        </div>
                    </div>
                    <div class="row upset">
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="col-lg-4 col-sm-6 mt30">
                            <div class="s-block up-hor">
                                <div class="s-card-icon">
                                    <img src="images/icons/data-copy.svg" alt="service" class="img-fluid">
                                </div>
                                <p>BACKUP & RECOVERY</p>
                            </div>
                        </div>
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="col-lg-4 col-sm-6 mt30">
                            <div class="s-block up-hor">
                                <div class="s-card-icon">
                                    <img src="images/icons/seo.svg" alt="service" class="img-fluid">
                                </div>
                                <p>WEB DEVELOPMENT</p>
                            </div>
                        </div>
                        <div data-tilt data-tilt-max="20" data-tilt-speed="1000" class="col-lg-4 col-sm-6 mt30">
                            <div class="s-block up-hor">
                                <div class="s-card-icon">
                                    <img src="images/icons/cloud.svg" alt="service" class="img-fluid">
                                </div>
                                <p>CLOUD SOLUTIONS</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End  work-category-->
    <!--Start Enquire Form-->
    <section class="enquire-form pad-tb">
        <div class="container">
            <div class="row light-bgs">
                <div class="col-lg-6">
                    <div class="common-heading text-l">
                        <span>Contact Now</span>
                        <h2 class="mt0">Have Question? Write a Message</h2>
                    </div>
                    <div class="form-block">
                    <form id="contact-form" method="post" data-toggle="validator" novalidate="true">
                        <input type="hidden" name="sendMail">
                        <div class="messages"></div>
                        <div class="fieldsets row">
                            <div class="col-md-6 form-group">
                                <input id="form_name" class="valid" type="text" name="name"
                                    placeholder="Enter your name *">
                                <div class="msg0 hide help-block with-errors">Enter Name</div>
                            </div>
                            <div class="col-md-6 form-group">
                                <input id="form_email" class="valid" type="email" name="email"
                                    placeholder="Enter your email *" required>
                                <div class="msg1 hide help-block with-errors">Enter E-Mail</div>
                            </div>
                        </div>
                        <div class="fieldsets row">
                            <div class="col-md-6 form-group">
                                <input id="form_phone" onkeypress='return event.charCode >= 48 && event.charCode <= 57'
                                    maxlength="10" class="valid" type="text" name="phone"
                                    placeholder="Enter your Phone No *">
                                <div class="msg2 hide help-block with-errors">Enter Mobile Number</div>
                            </div>
                            <div class="col-md-6 form-group">
                                <input id="form_phone" class="valid" type="text" name="need"
                                    placeholder="Enter Subject">
                                <div class="msg3 hide help-block with-errors">Enter Subject</div>
                            </div>
                        </div>
                        <div class="fieldsets form-group">
                            <textarea id="form_message" class="valid" name="message" placeholder="Message for me *"
                                rows="4"></textarea>
                            <div class="msg4 hide help-block with-errors">Mark Description</div>
                        </div>

                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck" name="example1"
                                checked="checked">
                            <label class="custom-control-label" for="customCheck">I agree to the
                                <a href="terms-conditions">Terms &amp; Conditions</a> of Trinity Info.</label>
                        </div>
                        <div class="fieldsets mt20">
                            <button type="submit" class="lnk btn-main bg-btn disabled">Submit <span
                                    class="circle dkpr"></span></button>
                        </div>
                        <p class="trm"><i class="fas fa-lock"></i>We hate spam, and we respect your privacy.</p>
                    </form>
                    </div>
                </div>
                <div class="col-lg-6 v-center">
                    <div class="enquire-image">
                        <img src="images/about/contact.svg" alt="enquire" class="img-fluid" />
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Enquire Form-->
    
<!-- Modal -->
<div class="popup-modalfull">
    <div class="modal loader" id="modalform-full">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center mt30">
                            <div class="col-md-9">
                                <div class="form-block fdgn2 mt10 mb10">
                                    <img src="./images/loader.gif" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup-modalfull">
    <div class="modal success" id="modalform-full">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center mt30">
                            <div class="col-md-9">
                                <div class="form-block fdgn2 mt10 mb10">
                                    <img src="./images/success.gif" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup-modalfull">
    <div class="modal failed" id="modalform-full">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="container">
                        <div class="row justify-content-center mt30">
                            <div class="col-md-9">
                                <div class="form-block fdgn2 mt10 mb10">
                                    <img src="./images/failed.gif" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal End -->
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>
<script>
$('#contact-form').submit(function(e) {
    e.preventDefault();
    var input = document.getElementsByClassName('valid');
    let count = 0;
    for (i = 0; i < input.length; i++) {
        if (input[i].value == "") {
            $('.msg' + i).removeClass('hide');
        } else {
            $('.msg' + i).addClass('hide');
            count++;
        }
    }
    if (count == input.length) {
        $.ajax({
            type: 'post',
            url: 'sendMail.php',
            data: $('form').serialize(),
            beforeSend: function() {
                $('.loader').show();
            },
            success: function(data) {
                $('.loader').hide();
                if (data) {
                    $('.success').show();
                    setTimeout(() => {
                        $('.success').hide();
                    }, 2000);
                } else {
                    $('.failed').show();
                    setTimeout(() => {
                        $('.failed').hide();
                    }, 2000);
                }
            }
        });
    }
});
</script>
</body>

</html>