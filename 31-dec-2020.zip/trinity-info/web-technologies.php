<?php
    include './phplib/header.php';
    include './phplib/navbar.php';
?>
<style>
header.nav-bg-w.main-header.navfix.fixed-top {
    background-color: #fff;
}
</style>

<section class="hero-card-web bg-gradient12 shape-bg3">
    <div class="hero-main-rp container-fluid">
        <div class="row">
            <div class="col-lg-5">
                <div class="hero-heading-sec">
                    <h2 class="wow fadeIn" data-wow-delay="0.3s"><span>We give wings to</span> <span>your business, you</span>
                        <span>decide where to fly</span>
                    </h2>
                    <p class="wow fadeIn" data-wow-delay="0.6s">WE DESIGN DIGITAL SOLUTIONS
                        FOR BRANDS AND COMPANIES</p>
                    <a href="coming-soon" class="btn-main bg-btn lnk wow fadeIn" data-wow-delay="0.8s">Learn More <i
                            class="fas fa-chevron-right fa-ani"></i><span class="circle"></span></a>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="hero-right-scmm">
                    <div class="hero-service-cards wow fadeInRight" data-wow-duration="2s">
                        <div class="owl-carousel service-card-prb">
                            <div class="service-slide card-bg-a" data-tilt data-tilt-max="5" data-tilt-speed="1000">
                                <a href="#">
                                    <div class="service-card-hh">
                                        <div class="image-sr-mm">
                                            <img alt="custom-sport" src="images/service/vr.png">
                                        </div>
                                        <div class="title-serv-c"><span>Card</span> 1</div>
                                    </div>
                                </a>
                            </div>
                            <div class="service-slide card-bg-b" data-tilt data-tilt-max="5" data-tilt-speed="1000">
                                <a href="#">
                                    <div class="service-card-hh">
                                        <div class="image-sr-mm">
                                            <img alt="custom-sport" src="images/service/app-develop.png">
                                        </div>
                                        <div class="title-serv-c"><span>Custom</span> App Solution</div>
                                    </div>
                                </a>
                            </div>
                            <div class="service-slide card-bg-c" data-tilt data-tilt-max="5" data-tilt-speed="1000">
                                <a href="#">
                                    <div class="service-card-hh">
                                        <div class="image-sr-mm">
                                            <img alt="custom-sport" src="images/service/startup.png">
                                        </div>
                                        <div class="title-serv-c"><span>Startup</span> Solution</div>
                                    </div>
                                </a>
                            </div>
                            <div class="service-slide card-bg-d" data-tilt data-tilt-max="5" data-tilt-speed="1000">
                                <a href="#">
                                    <div class="service-card-hh">
                                        <div class="image-sr-mm">
                                            <img alt="custom-sport" src="images/service/car-rental.png">
                                        </div>
                                        <div class="title-serv-c"><span>Car</span> Rental Solution</div>
                                    </div>
                                </a>
                            </div>
                            <div class="service-slide card-bg-e" data-tilt data-tilt-max="5" data-tilt-speed="1000">
                                <a href="#">
                                    <div class="service-card-hh">
                                        <div class="image-sr-mm">
                                            <img alt="custom-sport" src="images/service/marketing.png">
                                        </div>
                                        <div class="title-serv-c"><span>Marketing</span> Solution</div>
                                    </div>
                                </a>
                            </div>
                            <div class="service-slide card-bg-f" data-tilt data-tilt-max="5" data-tilt-speed="1000">
                                <a href="#">
                                    <div class="service-card-hh">
                                        <div class="image-sr-mm">
                                            <img alt="custom-sport" src="images/service/ewallet.png">
                                        </div>
                                        <div class="title-serv-c"><span>e-Wallet</span> Solution</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="service-section web-servic pad-tb">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="common-heading">
                    <span>Services We’re Provided</span>
                    <h2 class="mb30">Our Design &amp; Development Services</h2>
                </div>
            </div>
        </div>
        <div class="row upset link-hover shape-num justify-content-center">
            <div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.2s"
                style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                <div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000"
                    style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
                    <div class="s-card-icon"><img src="images/icons/branding.svg" alt="service" class="img-fluid"></div>
                    <h4>Logo &amp; Branding Service</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.4s"
                style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
                <div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000"
                    style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1); transition: all 1000ms cubic-bezier(0.03, 0.98, 0.52, 0.99) 0s;">
                    <div class="s-card-icon"><img src="images/icons/development.svg" alt="service" class="img-fluid">
                    </div>
                    <h4>Website Design &amp; Development</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.6s"
                style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                <div class="s-block" data-tilt="" data-tilt-max="5" data-tilt-speed="1000"
                    style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
                    <div class="s-card-icon"><img src="images/icons/app.svg" alt="service" class="img-fluid"></div>
                    <h4>Mobile App Development</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 mt30 shape-loc wow fadeInUp" data-wow-delay="0.8s"
                style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">
                <div class="s-block mb0" data-tilt="" data-tilt-max="5" data-tilt-speed="1000"
                    style="will-change: transform; transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1);">
                    <div class="s-card-icon"><img src="images/icons/marketing.svg" alt="service" class="img-fluid">
                    </div>
                    <h4>Digital Marketing Service</h4>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <a href="javascript:void(0)">Learn More <i class="fas fa-chevron-right fa-icon"></i></a>
                </div>
            </div>
        </div>
        <div class="-cta-btn mt70">
            <div class="free-cta-title v-center wow zoomInDown" data-wow-delay=".9s"
                style="visibility: visible; animation-delay: 0.9s; animation-name: zoomInDown;">
                <p>Hire a <span>Dedicated Developer</span></p>
                <a href="hire-developer" class="btn-main bg-btn2 lnk">Hire Now<i class="fas fa-chevron-right fa-icon"></i><span
                        class="circle"></span></a>
            </div>
        </div>
    </div>
</section>
</body>
<?php 
    include './phplib/footer.php'; 
    include './phplib/scripts.php';
?>

</html>