<?php

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'phpmailer/Exception.php';
    require 'phpmailer/PHPMailer.php';
    require 'phpmailer/SMTP.php';
    require 'phpmailer/OAuth.php';
    require 'phpmailer/POP3.php';

    if(isset($_POST["sendMail"]))
    {
        $mail = new PHPMailer(true);
        $mail->IsHTML(true);
        $mail->IsSMTP();
        $mail->SMTPAuth = true;

        $mail->Host = 'smtp.hostinger.in';
        $mail->Port = 587;
        $mail->Username = 'info@trinity-info-pvt-ltd.com';
        $mail->Password = '9go6tNPS6f';

        $mail->SetFrom('naveen@trinity-info-pvt-ltd.com','Trinity Info Pvt LTD');
        $mail->Subject = 'New Enquiry From Site by '.ucwords($_POST["name"]);
        $mail->Body = 'Name : '.ucwords($_POST["name"]).'<br> Mail : '.$_POST["email"].'<br> Mobile : '.$_POST["phone"].'<br> Need : '.$_POST["need"].'<br> Message : '.$_POST["message"];
        $mail->AddAddress('info@trinity-info-pvt-ltd.com');

        if( !$mail->Send() ) 
        {
          echo false;
        }
        else
        { 
          echo true;
        }
    }
?>